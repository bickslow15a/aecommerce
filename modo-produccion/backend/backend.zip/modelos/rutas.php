<?php

class Ruta{

	/*=============================================
	RUTA LADO DEL CLIENTE
	=============================================*/	

	static public function ctrRuta(){

		return "https://ecommerce.tutorialesatualcance.com/";
	
	}

	/*=============================================
	RUTA LADO DEL SERVIDOR
	=============================================*/	

	static public function ctrRutaServidor(){

		return "https://backend.tutorialesatualcance.com/";
	
	}

}