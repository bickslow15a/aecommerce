<!-- main-sidebar -->
<aside class="main-sidebar">

	<!-- sidebar -->
    <section class="sidebar">

    	<?php

    	include "lateral/menu.php";

    	?>

    </section>
    <!-- /.sidebar -->

</aside>
<!-- main-sidebar -->